package com.example.demo;

public class KafkaSimpleConsumer {

}
